﻿using System;
using System.Collections.Generic;

namespace MyApp.Domain
{
    public class Samurai
    {
        public int Id { get; set; }

        public string Name { get; set; }

        // Navigation Property
        public List<Quote> Quotes { get; set; } = new List<Quote>();

        public List<Battle> Battles { get; set; } = new List<Battle>();

        public Horse Horse { get; set; }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using MyApp.Data;
using MyApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MyApp.UI
{
    class Program
    {
        private static MyAppContext _context = new MyAppContext();
        static void Main(string[] args)
        {
            //AddSamurais("Shimada", "Okamoto", "Kikuchio", "Hayashida");
            //AddVariousTypes();
            //GetSamurais();
            //ClientVsServer();
            //QueryAggregates();

            //RetrieveAndUpdateSamurai();
            //RetrieveAndUpdateMultipleSamurais();
            //MultipleDatabaseOperations();

            //RetrieveAndDeleteASamurai();

            QueryAndUpdateBattles_Disconnected();

            Console.Write("Press any key...");
            Console.ReadKey();
        }



        private static void AddVariousTypes()
        {
            //_context.Samurais.AddRange(
            //    new Samurai { Name = "Manish" },
            //    new Samurai { Name = "Abhijeet" });

            //_context.Battles.AddRange(
            //    new Battle { Name = "Battle of Anegawa" },
            //    new Battle { Name = "Battle of Nagashino" });

            _context.AddRange(
               new Samurai { Name = "Manish" },
               new Samurai { Name = "Abhijeet" },
               new Battle { Name = "Battle of Anegawa" },
               new Battle { Name = "Battle of Nagashino" });

            _context.SaveChanges();
        }

        private static void AddSamurais(params string[] names)
        {
            foreach (string name in names)
            {
                _context.Samurais.Add(new Samurai { Name = name });
            }
            _context.SaveChanges();
        }
        //private static void GetSamurais()
        //{
        //    //var samurais = _context.Samurais;
        //    //var samurais = _context.Samurais.ToList();

        //    // DB Connection will open with Loop Start and will close when loop Ends
        //    var samurais = _context.Samurais;
        //    foreach (var samurai in samurais)
        //    {
        //        Console.WriteLine(samurai.Name);
        //    }

        //    //var samurais = _context.Samurais.ToList();
        //    //foreach (var samurai in samurais)
        //    //{
        //    //    Console.WriteLine(samurai.Name);
        //    //}
        //}

        private static void GetSamurais()
        {
            //var samurais = _context.Samurais.Where(s => s.Name == "Sampson").ToList();
            //foreach (var samurai in samurais)
            //{
            //    Console.WriteLine(samurai.Name);
            //}

            //var name = "Sampson";
            //var samurais = _context.Samurais.Where(s => s.Name == name).ToList();
            //foreach (var samurai in samurais)
            //{
            //    Console.WriteLine(samurai.Name);
            //}

            var name = "Sam";
            //var samurais = _context.Samurais.Where(s => s.Name.Contains(name)).ToList();
            var samurais = _context.Samurais.Where(s => EF.Functions.Like(s.Name, name)).ToList();
            foreach (var samurai in samurais)
            {
                Console.WriteLine(samurai.Name);
            }
        }

        private static void ClientVsServer()
        {
            // Buffered vs Stream Result
            //var name = "Sam";
            //var samurais = _context.Samurais.Where(s => s.Name.Contains(name)).ToList();
            //var samurais = _context.Samurais.Where(s => s.Name.Contains(name)).AsEnumerable();
            //var samurais = _context.Samurais.Where(s => s.Name.Contains(name));
            //var samurais = _context.Samurais.Where(s => s.Name.Contains(name)).AsQueryable();

            //foreach (var samurai in samurais)
            //{
            //    Console.WriteLine(samurai.Name);
            //}

            //AddSamurais("Sampson5");
            //Console.WriteLine("\nAfter Insert");

            //foreach (var samurai in samurais)
            //{
            //    Console.WriteLine(samurai.Name);
            //}

            var name = "Sam";

            var samuraisList = _context.Samurais.Where(s => s.Name.Contains(name)).ToList();
            Console.WriteLine(samuraisList.FirstOrDefault().Name);
            //Console.WriteLine(samuraisList.Count());

            var samuraisEnumerable = _context.Samurais.Where(s => s.Name.Contains(name)).AsEnumerable();
            Console.WriteLine(samuraisEnumerable.FirstOrDefault().Name);
            //Console.WriteLine(samuraisEnumerable.Count());

            var samuraisQueryable = _context.Samurais.Where(s => s.Name.Contains(name)).AsQueryable();
            Console.WriteLine(samuraisQueryable.FirstOrDefault().Name);
            //Console.WriteLine(samuraisQueryable.Count());
        }

        private static void QueryAggregates()
        {
            // Unsupported client evaluation
            //var name = "Sam";
            //var samurai = _context.Samurais.Where(s => s.Name.Contains(name)).FirstOrDefault();
            //var samurai = _context.Samurais.Where(s => s.Name.Contains(name)).LastOrDefault();
            //var samurai = _context.Samurais.Where(s => s.Name.Contains(name)).OrderBy(s => s.Id).LastOrDefault();
            //Console.WriteLine(samurai.Name);

            //var name = "Sampson";
            ////var samurai = _context.Samurais.Where(s => s.Name == name).FirstOrDefault();
            //var samurai = _context.Samurais.FirstOrDefault(s => s.Name == name);
            //Console.WriteLine(samurai.Name);

            //Filter on the key value
            var samurai = _context.Samurais.FirstOrDefault(s => s.Id == 5);

            //var samurai1 = _context.Samurais.FirstOrDefault(s => s.Id == 5);
            var samurai1 = _context.Samurais.Find(5);

            Console.WriteLine("Result: {0}", samurai?.Name);
            Console.WriteLine("Result: {0}", samurai1?.Name);
        }

        private static void RetrieveAndUpdateSamurai()
        {
            var samurai = _context.Samurais.FirstOrDefault();
            samurai.Name += "San";
            _context.SaveChanges();

            Console.WriteLine("After Update: {0}", _context.Samurais.FirstOrDefault().Name);
        }

        private static void RetrieveAndUpdateMultipleSamurais()
        {
            var samurais = _context.Samurais.Skip(1).Take(4).ToList();
            samurais.ForEach(s => s.Name += "San");
            _context.SaveChanges();

            foreach (var s in _context.Samurais.Skip(1).Take(4))
            {
                Console.WriteLine(s.Name);
            }
        }

        private static void MultipleDatabaseOperations()
        {
            var samurai = _context.Samurais.FirstOrDefault();
            samurai.Name += "San";
            _context.Samurais.Add(new Samurai { Name = "Shino" });
            _context.SaveChanges();

            foreach (var s in _context.Samurais)
            {
                Console.WriteLine(s.Name);
            }
        }

        private static void RetrieveAndDeleteASamurai()
        {
            var samurai = _context.Samurais.Find(20);
            _context.Samurais.Remove(samurai);
            _context.SaveChanges();
        }

        private static void QueryAndUpdateBattles_Disconnected()
        {
            List<Battle> disconnectedBattles;
            using (var context1 = new MyAppContext())
            {
                disconnectedBattles = context1.Battles.ToList();
            } //context1 is disposed

            disconnectedBattles.ForEach(b =>
            {
                b.StartDate = new DateTime(1570, 01, 01);
                b.EndDate = new DateTime(1570, 12, 1);
                Console.WriteLine(_context.Entry(b).State);
            });

            using (var context2 = new Data.MyAppContext())
            {
                context2.UpdateRange(disconnectedBattles);
                context2.SaveChanges();
            }
        }
    }
}

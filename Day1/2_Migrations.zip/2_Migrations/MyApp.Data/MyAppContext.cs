﻿using Microsoft.EntityFrameworkCore;
using MyApp.Domain;
using System;

namespace MyApp.Data
{
    public class MyAppContext : DbContext
    {
        public DbSet<Samurai> Samurais { get; set; }
        public DbSet<Quote> Quotes { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                "Data Source=(localdb)\\MSSQLLocalDB; Initial Catalog=AppDataDB");
        }
    }
}

// In Development Env, we will use add-migration and update-database
// In Production Env, we will use add-migration and script-migration and share the script with DB Admin
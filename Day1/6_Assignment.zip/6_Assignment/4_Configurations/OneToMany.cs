﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace _4_Configurations
{
    //public class StudentAssign
    //{
    //    [Column("StudentId")]
    //    public Guid Id { get; set; }
    //    [Required]
    //    [MaxLength(50, ErrorMessage = "Length should be 50 characters")]
    //    public string Name { get; set; }
    //    public int? Age { get; set; }

    //    public ICollection<EvaluationAssign> Evaluations { get; set; }
    //}

    //public class EvaluationAssign
    //{
    //    [Column("EvaluationId")]
    //    public Guid Id { get; set; }
    //    [Required]
    //    public int Grade { get; set; }
    //    public string AdditionalExplanation { get; set; }

    //    public Guid StudentId { get; set; }                     // Not Null
    //    public StudentAssign Student { get; set; }
    //}

    //// Data Annotaion
    //public class StudentAssign
    //{
    //    [Column("StudentId")]
    //    public Guid Id { get; set; }
    //    [Required]
    //    [MaxLength(50, ErrorMessage = "Length should be 50 characters")]
    //    public string Name { get; set; }
    //    public int? Age { get; set; }

    //    public ICollection<EvaluationAssign> Evaluations { get; set; }
    //}

    ////public class EvaluationAssign
    ////{
    ////    [Column("EvaluationId")]
    ////    public Guid Id { get; set; }
    ////    [Required]
    ////    public int Grade { get; set; }
    ////    public string AdditionalExplanation { get; set; }

    ////    [ForeignKey(nameof(StudentAssign))]
    ////    public Guid StudentId { get; set; }                     // Not Null
    ////    public StudentAssign Student { get; set; }
    ////}

    //public class EvaluationAssign
    //{
    //    [Column("EvaluationId")]
    //    public Guid Id { get; set; }
    //    [Required]
    //    public int Grade { get; set; }
    //    public string AdditionalExplanation { get; set; }
    //    public Guid StudentId { get; set; }                     // Not Null
    //    [ForeignKey(nameof(StudentId))]
    //    public StudentAssign Student { get; set; }
    //}

    // Data Annotaion
    public class StudentAssign
    {
        [Column("StudentId")]
        public Guid Id { get; set; }
        [Required]
        [MaxLength(50, ErrorMessage = "Length should be 50 characters")]
        public string Name { get; set; }
        public int? Age { get; set; }

        public ICollection<EvaluationAssign> Evaluations { get; set; }
    }
    public class EvaluationAssign
    {
        [Column("EvaluationId")]
        public Guid Id { get; set; }
        [Required]
        public int Grade { get; set; }
        public string AdditionalExplanation { get; set; }
        public Guid StudentId { get; set; }                     // Not Null
        public StudentAssign Student { get; set; }
    }

}

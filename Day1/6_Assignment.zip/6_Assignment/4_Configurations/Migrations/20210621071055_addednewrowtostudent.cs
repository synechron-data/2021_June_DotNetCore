﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace _4_Configurations.Migrations
{
    public partial class addednewrowtostudent : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MyStudents",
                keyColumn: "StudentId",
                keyValue: new Guid("098d29f2-1a8c-43c9-8085-a8e5333210bd"));

            migrationBuilder.DeleteData(
                table: "MyStudents",
                keyColumn: "StudentId",
                keyValue: new Guid("929ffd4c-cd6e-4ffa-b55a-3047616c63cd"));

            migrationBuilder.InsertData(
                table: "MyStudents",
                columns: new[] { "StudentId", "Age", "Name" },
                values: new object[] { new Guid("2d566012-84df-47f3-9fb4-d2bcebbaa117"), 30, "Abhijeet" });

            migrationBuilder.InsertData(
                table: "MyStudents",
                columns: new[] { "StudentId", "Age", "Name" },
                values: new object[] { new Guid("405974bb-b884-47c7-8f78-66084f5a5f62"), 40, "Ramakant" });

            migrationBuilder.InsertData(
                table: "MyStudents",
                columns: new[] { "StudentId", "Age", "Name" },
                values: new object[] { new Guid("5c78e880-05ef-4b9f-9723-ba8c3dd4cb9f"), 39, "Manish" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MyStudents",
                keyColumn: "StudentId",
                keyValue: new Guid("2d566012-84df-47f3-9fb4-d2bcebbaa117"));

            migrationBuilder.DeleteData(
                table: "MyStudents",
                keyColumn: "StudentId",
                keyValue: new Guid("405974bb-b884-47c7-8f78-66084f5a5f62"));

            migrationBuilder.DeleteData(
                table: "MyStudents",
                keyColumn: "StudentId",
                keyValue: new Guid("5c78e880-05ef-4b9f-9723-ba8c3dd4cb9f"));

            migrationBuilder.InsertData(
                table: "MyStudents",
                columns: new[] { "StudentId", "Age", "Name" },
                values: new object[] { new Guid("929ffd4c-cd6e-4ffa-b55a-3047616c63cd"), 30, "Abhijeet" });

            migrationBuilder.InsertData(
                table: "MyStudents",
                columns: new[] { "StudentId", "Age", "Name" },
                values: new object[] { new Guid("098d29f2-1a8c-43c9-8085-a8e5333210bd"), 40, "Ramakant" });
        }
    }
}

﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace _4_Configurations.Configuration
{
    public class StudentConfiguration : IEntityTypeConfiguration<Student>
    {
        public void Configure(EntityTypeBuilder<Student> builder)
        {
            builder.ToTable("MyStudents");
            builder.Property(s => s.Id).HasColumnName("StudentId");
            builder.Property(s => s.Name).IsRequired().HasMaxLength(50);
            builder.Property(s => s.Age).IsRequired(false);
            builder.Ignore(s => s.FeeCalculation);

            builder.HasData(
                    new Student
                    {
                        Id = Guid.NewGuid(),
                        Name = "Abhijeet",
                        Age = 30
                    },
                    new Student
                    {
                        Id = Guid.NewGuid(),
                        Name = "Ramakant",
                        Age = 40
                    },
                    new Student
                    {
                        Id = Guid.NewGuid(),
                        Name = "Manish",
                        Age = 39
                    }
                );
        }
    }
}

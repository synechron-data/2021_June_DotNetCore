﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace _4_Configurations.Configuration
{
    public class StudentAssignConfiguartion : IEntityTypeConfiguration<StudentAssign>
    {
        public void Configure(EntityTypeBuilder<StudentAssign> builder)
        {
            builder.HasMany(e => e.Evaluations)
                .WithOne(s => s.Student)
                .HasForeignKey(s => s.StudentId);
        }
    }
}

﻿using System;

namespace _3_DBContextFromExistingDB
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

// Install the provider and Tools
// On PMC window, run the following command
// scaffold-dbcontext -provider Microsoft.EntityFrameworkCore.SqlServer -connection "Data Source=(LocalDB)\MSSQLLocalDB; Initial Catalog=AppDataDB"

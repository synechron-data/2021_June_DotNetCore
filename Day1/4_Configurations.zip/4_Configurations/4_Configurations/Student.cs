﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace _4_Configurations
{
    //[Table("MyStudents")]
    public class Student
    {
        //[Key]
        //[Column("StudentId")]
        public Guid Id { get; set; }
        //[Required]
        //[MaxLength(50, ErrorMessage = "Length should be 50 characters")]
        public string Name { get; set; }
        public int? Age { get; set; }

        //[NotMapped]
        public int FeeCalculation { get; set; }
    }
}

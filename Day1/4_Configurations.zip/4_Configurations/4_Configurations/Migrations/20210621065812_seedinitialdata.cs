﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace _4_Configurations.Migrations
{
    public partial class seedinitialdata : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "MyStudents",
                columns: new[] { "StudentId", "Age", "Name" },
                values: new object[] { new Guid("929ffd4c-cd6e-4ffa-b55a-3047616c63cd"), 30, "Abhijeet" });

            migrationBuilder.InsertData(
                table: "MyStudents",
                columns: new[] { "StudentId", "Age", "Name" },
                values: new object[] { new Guid("098d29f2-1a8c-43c9-8085-a8e5333210bd"), 40, "Ramakant" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MyStudents",
                keyColumn: "StudentId",
                keyValue: new Guid("098d29f2-1a8c-43c9-8085-a8e5333210bd"));

            migrationBuilder.DeleteData(
                table: "MyStudents",
                keyColumn: "StudentId",
                keyValue: new Guid("929ffd4c-cd6e-4ffa-b55a-3047616c63cd"));
        }
    }
}

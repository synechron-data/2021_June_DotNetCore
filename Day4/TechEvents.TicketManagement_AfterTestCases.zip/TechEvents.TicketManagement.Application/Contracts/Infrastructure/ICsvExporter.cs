﻿using System;
using System.Collections.Generic;
using System.Text;
using TechEvents.TicketManagement.Application.Features.Events.Queries.GetEventsExport;

namespace TechEvents.TicketManagement.Application.Contracts.Infrastructure
{
    public interface ICsvExporter
    {
        byte[] ExportEventsToCsv(List<EventExportDto> eventExportDtos);
    }
}

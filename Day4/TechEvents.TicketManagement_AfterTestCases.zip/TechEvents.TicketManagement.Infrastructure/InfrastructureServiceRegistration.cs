﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using TechEvents.TicketManagement.Application.Contracts.Infrastructure;
using TechEvents.TicketManagement.Application.Models.Mail;
using TechEvents.TicketManagement.Infrastructure.FileExport;
using TechEvents.TicketManagement.Infrastructure.Mail;

namespace TechEvents.TicketManagement.Infrastructure
{
    public static class InfrastructureServiceRegistration
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.Configure<EmailSettings>(configuration.GetSection("EmailSettings"));

            services.AddTransient<IEmailService, EmailService>();
            services.AddTransient<ICsvExporter, CsvExporter>();

            return services;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceLifetimeDemo.Services
{
    public class GuidProcessService : IScopedService, ITransientService, ISingletonService
    {
        Guid id;

        public GuidProcessService()
        {
            id = Guid.NewGuid();
        }

        public Guid GetNewGuid()
        {
            return id;
        }
    }
}

﻿using AutoMapper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TechEvents.TicketManagement.Application.Contracts.Persistence;
using TechEvents.TicketManagement.Application.Features.Categories.Queries.GetCategoriesList;
using TechEvents.TicketManagement.Application.Profiles;
using TechEvents.TicketManagement.Application.UnitTests.Mocks;
using TechEvents.TicketManagement.Domain.Entities;

namespace TechEvents.TicketManagement.Application.UnitTests.Categories
{
    [TestClass]
    public class GetCategoriesListQueryHandlerTests
    {
        private readonly IMapper _mapper;
        private readonly Mock<IAsyncRepository<Category>> _mockCategoryRepository;

        public GetCategoriesListQueryHandlerTests()
        {
            _mockCategoryRepository = RepositoryMocks.GetCategoryRepository();
            var configurationProvider = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile<MappingProfile>();
            });

            _mapper = configurationProvider.CreateMapper();
        }

        [TestMethod]
        public async Task GetCategoriesListTest()
        {
            // Arrange
            var handler = new GetCategoriesListQueryHandler(_mapper, _mockCategoryRepository.Object);

            // Act
            var result = await handler.Handle(new GetCategoriesListQuery(), CancellationToken.None);

            // Assert
            CollectionAssert.AllItemsAreInstancesOfType(result, typeof(CategoryListVm));
            Assert.AreEqual(4, result.Count);
        }
    }
}

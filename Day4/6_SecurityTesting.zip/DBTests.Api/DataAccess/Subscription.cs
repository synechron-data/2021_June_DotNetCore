﻿using DBTests.Api.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.Api.DataAccess
{
    public class Subscription : Int32Identity
    {
        public string Username { get; set; }
        public string SubscriptionLevel { get; set; }
    }
}

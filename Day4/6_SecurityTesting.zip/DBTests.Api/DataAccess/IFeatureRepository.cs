﻿using DBTests.DataAccess;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.Api.DataAccess
{
    public interface IFeatureRepository : IRepository<Feature>
    {
        IList<Feature> GetByUsername(string username);
    }
}

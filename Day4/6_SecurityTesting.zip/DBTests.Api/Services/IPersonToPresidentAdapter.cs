﻿using DBTests.Api.DataAccess;
using DBTests.Api.Models;
using System;
using System.Collections.Generic;

namespace DBTests.Api.Services
{
    public interface IPersonToPresidentAdapter
    {
        void Adapt(IEnumerable<Person> fromValues, IList<President> toValues);
        void Adapt(Person fromValue, President toValue);
        void Adapt(President fromValue, Person toValue);
        void AdaptValueToPersonFact(DateTime fromValue, Person toPerson, string toPersonFactType);
        void AdaptValueToPersonFact(string fromValue, Person toPerson, string toPersonFactType);
    }
}
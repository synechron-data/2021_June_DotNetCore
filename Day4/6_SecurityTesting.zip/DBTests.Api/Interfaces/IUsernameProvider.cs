﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.Api.Interfaces
{
    public interface IUsernameProvider
    {
        string GetUsername();
    }
}

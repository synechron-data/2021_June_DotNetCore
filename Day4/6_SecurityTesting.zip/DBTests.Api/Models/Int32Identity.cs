﻿using DBTests.DataAccess;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.Api.Models
{
    public abstract class Int32Identity : IInt32Identity
    {
        public int Id { get; set; }
    }
}

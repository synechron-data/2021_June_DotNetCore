﻿using DBTests.WebUI;
using DBTests.WebUI.Security;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace DBTests.UnitTests.Security
{
    [TestClass]
    public class EditPresidentHandlerFixture
    {
        [TestMethod]
        public async Task HandlerSucceedsWhenUserIsAuthorizedToEdit_Administrator()
        {
            var tester = new AuthorizationHandlerTester<EditPresidentRequirement, EditPresidentHandler>(
                new EditPresidentRequirement(), new EditPresidentHandler());

            tester.AddRouteDataValue("id", 123);
            tester.AddClaim(ClaimTypes.Role, SecurityConstants.RoleName_Admin);

            await tester.AssertSuccess();
        }

        [TestMethod]
        public async Task HandlerFailsWhenUserIsAuthorizedToEdit()
        {
            var tester = new AuthorizationHandlerTester<EditPresidentRequirement, EditPresidentHandler>(
                new EditPresidentRequirement(), new EditPresidentHandler());

            tester.AddRouteDataValue("id", 123);
            //tester.AddClaim(ClaimTypes.Role, SecurityConstants.RoleName_Admin);

            await tester.AssertFailure();
        }
    }
}

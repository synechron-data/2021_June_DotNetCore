﻿using DBTests.Api.Models;
using DBTests.WebUI;
using DBTests.WebUI.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.UnitTests.Security
{
    [TestClass]
    public class PresidentControllerSecurityFixture
    {
        private Type SystemUnderTest
        {
            get
            {
                return typeof(PresidentController);
            }
        }

        [TestMethod]
        [Ignore]
        public void EditMethodRequiresAdministratorRole_Int32()
        {
            SecurityAttributeUtility.AssertAuthorizeAttributeRolesOnMethod(
                SecurityConstants.RoleName_Admin, SystemUnderTest, "Edit", typeof(int));
        }

        [TestMethod]
        [Ignore]
        public void EditMethodRequiresAdministratorRole_President()
        {
            SecurityAttributeUtility.AssertAuthorizeAttributeRolesOnMethod(
                SecurityConstants.RoleName_Admin, SystemUnderTest, "Edit", typeof(President));
        }

        [TestMethod]
        public void EditMethodRequiresAdministratorPolicy_Int32()
        {
            SecurityAttributeUtility.AssertAuthorizeAttributePolicyOnMethod(
                SecurityConstants.PolicyName_EditPresident,
                SystemUnderTest,
                "Edit",
                typeof(int));
        }

        [TestMethod]
        public void EditMethodRequiresAdministratorPolicy_President()
        {
            SecurityAttributeUtility.AssertAuthorizeAttributePolicyOnMethod(
                SecurityConstants.PolicyName_EditPresident,
                SystemUnderTest,
                "Edit",
                typeof(President));
        }
    }
}

﻿using DBTests.Api.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.UnitTests.Models
{
    [TestClass]
    public class PresidentFixture
    {
        [TestInitialize]
        public void OnTestInitialize()
        {
            _systemUnderTest = null;
        }

        private President _systemUnderTest;

        private President SystemUnderTest
        {
            get
            {
                if (_systemUnderTest == null)
                {
                    _systemUnderTest = new President();
                }

                return _systemUnderTest;
            }
        }

        [TestMethod]
        public void TermsCollectionIsNotNull()
        {
            Assert.IsNotNull(SystemUnderTest.Terms);
        }

        [TestMethod]
        public void FieldsAreInitialized()
        {
            Assert.AreEqual<string>(String.Empty, SystemUnderTest.BirthCity, "BirthCity should be empty.");
            Assert.AreEqual<string>(String.Empty, SystemUnderTest.BirthState, "BirthState should be empty.");
            Assert.AreEqual<string>(String.Empty, SystemUnderTest.DeathCity, "DeathCity should be empty.");
            Assert.AreEqual<string>(String.Empty, SystemUnderTest.DeathState, "DeathState should be empty.");
            Assert.AreEqual<string>(String.Empty, SystemUnderTest.FirstName, "FirstName should be empty.");
            Assert.AreEqual<string>(String.Empty, SystemUnderTest.LastName, "LastName should be empty.");
        }
    }
}

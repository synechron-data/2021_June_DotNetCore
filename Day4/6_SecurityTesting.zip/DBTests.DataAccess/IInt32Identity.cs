﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBTests.DataAccess
{
    public interface IInt32Identity
    {
        int Id { get; set; }
    }
}

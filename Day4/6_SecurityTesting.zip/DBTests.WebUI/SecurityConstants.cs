﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DBTests.WebUI
{
    public static class SecurityConstants
    {
        public const string RoleName_Admin = "Presidents.Admin";
        public const string RoleName_User = "Presidents.User";

        public const string PermissionName_View = "President.View";
        public const string PermissionName_Edit = "President.Edit";

        public const string PolicyName_EditPresident = "EditPresidentPolicy";

        public const string SubscriptionType_Basic = "Basic";
        public const string SubscriptionType_Ultimate = "Ultimate";

        public const string Claim_SubscriptionType = "SubscriptionType";
    }
}

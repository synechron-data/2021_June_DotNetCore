﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ServiceLifetimeDemo.Services
{
    public interface ISingletonService
    {
        Guid GetNewGuid();
    }
}

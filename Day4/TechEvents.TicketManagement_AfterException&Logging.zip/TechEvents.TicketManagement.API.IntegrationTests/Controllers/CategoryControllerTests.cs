﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TechEvents.TicketManagement.Api;
using TechEvents.TicketManagement.API.IntegrationTests.Base;
using TechEvents.TicketManagement.Application.Features.Categories.Queries.GetCategoriesList;

namespace TechEvents.TicketManagement.API.IntegrationTests.Controllers
{
    [TestClass]
    public class CategoryControllerTests
    {
        private CustomWebApplicationFactory<Startup> _systemUnderTest;

        public CustomWebApplicationFactory<Startup> SystemUnderTest
        {
            get
            {
                if (_systemUnderTest == null)
                {
                    _systemUnderTest = new CustomWebApplicationFactory<Startup>();
                }
                return _systemUnderTest;
            }
        }

        [TestMethod]
        public async Task ReturnsSuccessResult()
        {
            var client = SystemUnderTest.GetAnonymousClient();

            var response = await client.GetAsync("/api/category/all");

            response.EnsureSuccessStatusCode();

            var responseString = await response.Content.ReadAsStringAsync();

            var result = JsonConvert.DeserializeObject<List<CategoryListVm>>(responseString);

            CollectionAssert.AllItemsAreInstancesOfType(result, typeof(CategoryListVm));
            CollectionAssert.AllItemsAreNotNull(result);
        }
    }
}

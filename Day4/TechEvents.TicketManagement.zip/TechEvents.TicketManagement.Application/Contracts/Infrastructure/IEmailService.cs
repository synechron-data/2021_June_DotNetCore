﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TechEvents.TicketManagement.Application.Models.Mail;

namespace TechEvents.TicketManagement.Application.Contracts.Infrastructure
{
    public interface IEmailService
    {
        Task<bool> SendEmail(Email email);
    }
}

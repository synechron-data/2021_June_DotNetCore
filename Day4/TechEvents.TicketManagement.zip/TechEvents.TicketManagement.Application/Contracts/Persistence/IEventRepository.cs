﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TechEvents.TicketManagement.Domain.Entities;

namespace TechEvents.TicketManagement.Application.Contracts.Persistence
{
    public interface IEventRepository : IAsyncRepository<Event>
    {
        Task<bool> IsEventNameAndDateUnique(string name, DateTime eventDate);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;
using TechEvents.TicketManagement.Domain.Common;

namespace TechEvents.TicketManagement.Domain.Entities
{
    public class Category : AuditableEntity
    {
        public Guid CategoryId { get; set; }
        public string Name { get; set; }
        public ICollection<Event> Events { get; set; }
    }
}

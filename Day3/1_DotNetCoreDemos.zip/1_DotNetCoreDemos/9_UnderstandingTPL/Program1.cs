﻿using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using System;
using System.IO;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace _9_UnderstandingTPL
{
    class Program1
    {
        static bool done = false;

        static void Main(string[] args)
        {
            Console.WriteLine("Main, Thread Id: {0}", Thread.CurrentThread.ManagedThreadId);

            DownloadAndBlur();
            //DownloadAndBlurAsync();

            while (!done)
            {
                Console.CursorLeft = 0;
                Console.Write(System.DateTime.Now.ToString("HH:mm:ss.fff"));
                Thread.Sleep(50);
            }

            Console.WriteLine();
            Console.WriteLine("Done!");
        }
        private static void DownloadAndBlur()
        {
            Console.WriteLine("DownloadAndBlur, Thread Id: {0}", Thread.CurrentThread.ManagedThreadId);

            var url = "https://tinyjpg.com/images/social/website.jpg";
            var fileName = Path.GetFileName(url);

            DownloadImage(url).ContinueWith(task1 =>
            {
                var originalImageBytes = task1.Result;
                var originalImagePath = Path.Combine(Directory.GetCurrentDirectory(), fileName);
                SaveImage(originalImageBytes, originalImagePath).ContinueWith(task2 =>
                {
                    BlurImage(originalImagePath).ContinueWith(task3 =>
                    {
                        var blurredImageBytes = task3.Result;
                        var blurredFileName = $"{Path.GetFileNameWithoutExtension(fileName)}_blurred.jpg";
                        var blurredImagePath = Path.Combine(Directory.GetCurrentDirectory(), blurredFileName);
                        SaveImage(blurredImageBytes, blurredImagePath).ContinueWith(task4 =>
                        {
                            Thread.Sleep(5000);
                            done = true;

                            if (task4.Status == TaskStatus.Faulted && task4.Exception != null)
                            {
                                foreach (var ex in task4.Exception.InnerExceptions)
                                {
                                    Console.WriteLine($"\n\nException: {ex}\n");
                                }
                            }
                        });
                    });
                });
            });
        }

        private static async void DownloadAndBlurAsync()
        {
            Console.WriteLine("DownloadAndBlur, Thread Id: {0}", Thread.CurrentThread.ManagedThreadId);

            try
            {
                var url = "https://tinyjpg.com/images/social/website.jpg";
                var fileName = Path.GetFileName(url);
                var originalImageBytes = await DownloadImage(url);
                var originalImagePath = Path.Combine(Directory.GetCurrentDirectory(), fileName);
                await SaveImage(originalImageBytes, originalImagePath);
                var blurredImageBytes = await BlurImage(originalImagePath);
                var blurredFileName = $"{Path.GetFileNameWithoutExtension(fileName)}_blurred.jpg";
                var blurredImagePath = Path.Combine(Directory.GetCurrentDirectory(), blurredFileName);
                await SaveImage(blurredImageBytes, blurredImagePath);
                //await Task.Delay(5000);
                done = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"\n\nException: {ex.Message}\n");
                done = true;
            }
        }

        //static void Check()
        //{
        //    var await = 10;
        //    Console.WriteLine(await);
        //}

        static Task<byte[]> DownloadImage(string url)
        {
            //Console.WriteLine("DownloadImage, Thread Id: {0}", Thread.CurrentThread.ManagedThreadId);

            //return Task.FromResult(new byte[] { });
            var client = new HttpClient();
            return client.GetByteArrayAsync(url);
        }
        static async Task<byte[]> BlurImage(string imagePath)
        {
            //return Task.FromResult(new byte[] { });
            return await Task.Run(() =>
            {
                var image = Image.Load(imagePath);
                image.Mutate(ctx => ctx.GaussianBlur());
                using (var memoryStream = new MemoryStream())
                {
                    image.SaveAsJpeg(memoryStream);
                    return memoryStream.ToArray();
                }
            });
        }
        static async Task SaveImage(byte[] bytes, string imagePath)
        {
            //return Task.CompletedTask;
            //return Task.FromException(new Exception("Saving Failed"));
            using (var fileStream = new FileStream(imagePath, FileMode.Create))
            {
                await fileStream.WriteAsync(bytes, 0, bytes.Length);
            }
        }
    }
}

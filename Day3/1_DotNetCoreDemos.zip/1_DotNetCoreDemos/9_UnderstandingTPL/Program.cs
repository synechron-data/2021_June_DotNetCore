﻿using System;
using System.IO;
using System.Threading;

namespace _9_UnderstandingTPL
{
    class Program
    {
        static bool done = false;

        static void Main(string[] args)
        {
            DownloadAndBlur();

            while (!done)
            {
                Console.CursorLeft = 0;
                Console.Write(System.DateTime.Now.ToString("HH:mm:ss.fff"));
                Thread.Sleep(50);
            }

            Console.WriteLine();
            Console.WriteLine("Done!");
        }
        private static void DownloadAndBlur()
        {
            var url = "https://tinyjpg.com/images/social/website.jpg";
            var fileName = Path.GetFileName(url);
            var bytes = DownloadImage(url);
            
            var originalImagePath = Path.Combine(Directory.GetCurrentDirectory(), fileName);
            SaveImage(bytes, originalImagePath);
            
            var blurred = BlurImage(originalImagePath);
           
            var blurredFileName = $"{Path.GetFileNameWithoutExtension(fileName)}_blurred.jpg";
            var blurredImagePath = Path.Combine(Directory.GetCurrentDirectory(), blurredFileName);
            SaveImage(blurred, blurredImagePath);
            Thread.Sleep(5000);
        }

        static byte[] DownloadImage(string url) {
            return new byte[] { };
        }

        static byte[] BlurImage(string imagePath) {
            return new byte[] { };
        }
        static void SaveImage(byte[] bytes, string imagePath)
        {
        }
    }
}

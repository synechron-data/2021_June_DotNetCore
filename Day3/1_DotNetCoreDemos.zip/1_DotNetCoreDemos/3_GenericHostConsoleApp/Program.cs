﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;

namespace _3_GenericHostConsoleApp
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    Host.CreateDefaultBuilder(args).Build().Run();
        //}

        private static async Task Main(string[] args)
        {
            //await Host.CreateDefaultBuilder(args).Build().RunAsync();
            //Console.WriteLine("Hello From Main Method");

            await Host.CreateDefaultBuilder(args)
                .UseContentRoot(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location))
                .ConfigureServices((hostContext, services) =>
                {
                    services
                        .AddHostedService<ConsoleHostedService>()
                        .AddSingleton<IWeatherService, WeatherService>();

                    services.AddOptions<WeatherSettings>().Bind(hostContext.Configuration.GetSection("Weather"));
                })
                .RunConsoleAsync();

            //await Host.CreateDefaultBuilder(args)
            //    .ConfigureLogging(logging =>
            //    {
            //        // Add any 3rd party loggers like NLog or Serilog
            //    })
            //    .ConfigureServices((hostContext, services) =>
            //    {
            //        services
            //            .AddHostedService<ConsoleHostedService>()
            //            .AddSingleton<IWeatherService, WeatherService>();
            //    })
            //    .RunConsoleAsync();
        }
    }
}

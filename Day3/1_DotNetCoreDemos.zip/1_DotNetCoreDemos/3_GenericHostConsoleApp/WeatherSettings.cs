﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3_GenericHostConsoleApp
{
    public class WeatherSettings
    {
        public string Unit { get; set; }
    }
}

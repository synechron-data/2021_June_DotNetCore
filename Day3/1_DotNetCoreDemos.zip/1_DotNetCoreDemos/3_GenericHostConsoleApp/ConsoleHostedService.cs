﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace _3_GenericHostConsoleApp
{
    internal class ConsoleHostedService : IHostedService
    {
        private readonly ILogger _logger;
        private readonly IHostApplicationLifetime _appLifetime;
        private readonly IWeatherService _weatherService;

        public ConsoleHostedService(
            ILogger<ConsoleHostedService> logger,
            IHostApplicationLifetime appLifetime,
            IWeatherService weatherService)
        {
            _logger = logger;
            _appLifetime = appLifetime;
            _weatherService = weatherService;
        }
        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogDebug($"Starting with arguments: {string.Join(" ", Environment.GetCommandLineArgs())}");
            _appLifetime.ApplicationStarted.Register(() =>
            {
                Task.Run(async () =>
                {
                    try
                    {
                        //_logger.LogInformation("\nHello World!\n");
                        //await Task.Delay(1000);
                        IReadOnlyList<int> temperatures = await _weatherService.GetFiveDayTemperaturesAsync();
                        for (int i = 0; i < temperatures.Count; i++)
                        {
                            _logger.LogInformation($"{DateTime.Today.AddDays(i).DayOfWeek}: {temperatures[i]}");
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Unhandled exception!");
                    }
                    finally
                    {
                        _appLifetime.StopApplication();
                    }
                });
            });

            _appLifetime.ApplicationStopping.Register(() =>
            {
                Task.Run(() =>
                {
                    try
                    {
                        _logger.LogInformation("\nApplication is going to exit!\n");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Unhandled exception!");
                    }
                });
            });

            _appLifetime.ApplicationStopped.Register(() =>
            {
                Task.Run(() =>
                {
                    try
                    {
                        _logger.LogInformation("\nApplication is stopped!\n");
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex, "Unhandled exception!");
                    }
                });
            });

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            return Task.CompletedTask;
        }
    }
}
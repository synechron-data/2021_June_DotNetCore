﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TechEvents.TicketManagement.Domain.Entities;

namespace TechEvents.TicketManagement.Application.Contracts.Persistence
{
    public interface ICategoryRepository : IAsyncRepository<Category>
    {
        Task<List<Category>> GetCategoriesWithEvents(bool includePassedEvents);
    }
}

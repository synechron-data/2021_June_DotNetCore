﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using TechEvents.TicketManagement.Application.Features.Categories.Commands.CreateCategory;
using TechEvents.TicketManagement.Application.Features.Categories.Queries.GetCategoriesList;
using TechEvents.TicketManagement.Application.Features.Categories.Queries.GetCategoriesListWithEvents;
using TechEvents.TicketManagement.Application.Features.Events.Commands.CreateEvent;
using TechEvents.TicketManagement.Application.Features.Events.Commands.UpdateEvent;
using TechEvents.TicketManagement.Application.Features.Events.Queries.GetEventDetail;
using TechEvents.TicketManagement.Application.Features.Events.Queries.GetEventList;
using TechEvents.TicketManagement.Application.Features.Orders.GetOrdersForMonth;
using TechEvents.TicketManagement.Domain.Entities;

namespace TechEvents.TicketManagement.Application.Profiles
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Event, EventListVm>().ReverseMap();
            CreateMap<Event, CreateEventCommand>().ReverseMap();
            CreateMap<Event, UpdateEventCommand>().ReverseMap();
            CreateMap<Event, EventDetailVm>().ReverseMap();
            CreateMap<Event, CategoryEventDto>().ReverseMap();

            CreateMap<Category, CategoryDto>();
            CreateMap<Category, CategoryListVm>();
            CreateMap<Category, CategoryEventListVm>();
            CreateMap<Category, CreateCategoryCommand>();
            CreateMap<Category, CreateCategoryDto>();

            CreateMap<Order, OrdersForMonthDto>();
        }
    }
}

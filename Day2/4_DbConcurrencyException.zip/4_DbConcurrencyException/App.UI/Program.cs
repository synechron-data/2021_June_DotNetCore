﻿using App.Data;
using App.Domain;
using Microsoft.EntityFrameworkCore;
using System;

namespace App.UI
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var dbContext = new PayrollDataContext())
            {
                Employee employee = dbContext.Employees.Find(1);
                employee.Code = "Emp200";

                dbContext.Database.ExecuteSqlRaw(
                        "UPDATE dbo.Employees SET Address= 'Mumbai, MH, INDIA' WHERE Id = 1");

                var saveData = false;

                while (!saveData)
                {
                    try
                    {
                        dbContext.SaveChanges();
                    }
                    catch (DbUpdateConcurrencyException ex)
                    {
                        foreach (var item in ex.Entries)
                        {
                            if (item.Entity is Employee)
                            {
                                var currentValues = item.CurrentValues;
                                var dbValues = item.GetDatabaseValues();

                                foreach (var prop in currentValues.Properties)
                                {
                                    var currentValue = currentValues[prop];
                                    var dbValue = dbValues[prop];
                                }

                                // Refresh the original values to bypass next concurrency check
                                item.OriginalValues.SetValues(dbValues);
                            }
                            else
                            {
                                throw new NotSupportedException("Don’t know handling of concurrency conflict " + item.Metadata.Name);
                            }
                        }
                    }
                }
            }

            //using (var dbContext = new PayrollDataContext())
            //{
            //    EmployeeOne employee = dbContext.EmployeeOnes.Find(1);
            //    employee.Code = "Emp200";

            //    dbContext.Database.ExecuteSqlRaw(
            //            "UPDATE dbo.EmployeeOnes SET Address= 'Mumbai, MH, INDIA' WHERE Id = 1");

            //    var saveData = false;

            //    while (!saveData)
            //    {
            //        dbContext.SaveChanges();
            //    }
            //}
        }
    }
}

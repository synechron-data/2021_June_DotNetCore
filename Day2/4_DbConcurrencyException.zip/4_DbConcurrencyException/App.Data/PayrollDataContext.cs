﻿using App.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;

namespace App.Data
{
    public class PayrollDataContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }
        public DbSet<EmployeeOne> EmployeeOnes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
               "Data Source=(localdb)\\MSSQLLocalDB; Initial Catalog=EmployeesDB", options => options.MaxBatchSize(150))
               .LogTo(Console.WriteLine, new[] { DbLoggerCategory.Database.Command.Name },
                LogLevel.Information)
               .EnableSensitiveDataLogging(true);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<Employee>().Property(a => a.Code).IsConcurrencyToken();
            modelBuilder.Entity<Employee>().Property(a => a.Timestamp).IsRowVersion();
        }
    }
}

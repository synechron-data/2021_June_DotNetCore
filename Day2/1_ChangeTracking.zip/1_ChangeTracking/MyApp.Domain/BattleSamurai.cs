﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyApp.Domain
{
    public class BattleSamurai
    {
        public int SamuraiId { get; set; }

        public int BattleId { get; set; }

        public DateTime DateJoined { get; set; }
    }
}

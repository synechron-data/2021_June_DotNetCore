﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using MyApp.Data;
using MyApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MyApp.UI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Unchanged();
            //AddedState();
            ModifiedState();
            //RemovedState();
            //NoTrackingQuery();
            //NoTrackingOnContext();

            Console.Write("Press any key...");
            Console.ReadKey();
        }

        private static void Unchanged()
        {
            using (var context = new MyAppContext())
            {
                var samurai = context.Samurais.FirstOrDefault();
                //Console.WriteLine(context.Entry(samurai).State);
                DisplayStates(context.ChangeTracker.Entries());
            }
        }

        private static void AddedState()
        {
            using (var context = new MyAppContext())
            {
                var samurai = new Samurai { Name = "Manish" };
                //Console.WriteLine(context.Entry(samurai).State);
                context.Add(samurai);
                DisplayStates(context.ChangeTracker.Entries());
            }
        }

        private static void ModifiedState()
        {
            using (var context = new MyAppContext())
            {
                var samurai = context.Samurais.AsNoTracking().FirstOrDefault();
                //DisplayStates(context.ChangeTracker.Entries());
                Console.WriteLine(context.Entry(samurai).State);
                //samurai.Name = "Abhijeet";
                samurai.Quotes.Add(new Quote { Text = "Hello" });
                Console.WriteLine(context.Entry(samurai).State);
                DisplayStates(context.ChangeTracker.Entries());
            }
        }

        private static void RemovedState()
        {
            using (var context = new MyAppContext())
            {
                var samurai = context.Samurais.FirstOrDefault();
                DisplayStates(context.ChangeTracker.Entries());
                context.Samurais.Remove(samurai);
                DisplayStates(context.ChangeTracker.Entries());
            }
        }

        private static void NoTrackingQuery()
        {
            using (var context = new MyAppContext())
            {
                var samurai = context.Samurais.AsNoTracking().FirstOrDefault();
                Console.WriteLine(context.Entry(samurai).State);
                //context.Samurais.Remove(samurai);
                DisplayStates(context.ChangeTracker.Entries());
            }
        }

        private static void NoTrackingOnContext()
        {
            using (var context = new MyAppContext())
            {
                var samurai = context.Samurais.FirstOrDefault();
                Console.WriteLine(context.Entry(samurai).State);
                //context.Samurais.Remove(samurai);
                DisplayStates(context.ChangeTracker.Entries());
            }
        }

        private static void DisplayStates(IEnumerable<EntityEntry> entries)
        {
            foreach (var entry in entries)
            {
                Console.WriteLine($"\nEntity: {entry.Entity.GetType().Name}, " +
                    $"\nState: {entry.State}");
            }
        }
    }
}

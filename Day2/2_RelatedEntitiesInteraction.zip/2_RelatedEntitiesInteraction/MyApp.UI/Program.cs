﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using MyApp.Data;
using MyApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace MyApp.UI
{
    class Program
    {
        private static MyAppContext _context = new MyAppContext();

        static void Main(string[] args)
        {
            //InsertNewSamuraiWithAQuote();
            //InsertNewSamuraiWithManyQuotes();
            //AddQuoteToExistingSamuraiWhileTracked();
            //AddQuoteToExistingSamuraiNotTracked(4);
            //Simpler_AddQuoteToExistingSamuraiNotTracked(4);

            //EagerLoadSamuraiWithQuotes();
            //ProjectSomeProperties();
            //ProjectSamuraisWithQuotes();

            //ExplicitLoadQuotes();
            //LazyLoadQuotes();

            //ModifyingRelatedDataWhenTracked();
            //ModifyingRelatedDataWhenNotTracked();

            //AddingNewSamuraiToAnExistingBattle();
            //ReturnBattleWithSamurais();
            //ReturnAllBattlesWithSamurais();

            //AddAllSamuraisToAllBattles();

            //RemoveSamuraiFromABattle();
            //WillNotRemoveSamuraiFromABattle();

            //AddNewSamuraiWithHorse();
            //AddNewHorseToSamuraiUsingId();
            //AddNewHorseToSamuraiObject();
            //AddNewHorseToDisconnectedSamuraiObject();

            ReplaceAHorse();

            Console.Write("Press any key...");
            Console.ReadKey();
        }

        private static void InsertNewSamuraiWithAQuote()
        {
            var samurai = new Samurai
            {
                Name = "Kambei Shimada",
                Quotes = new List<Quote>
                {
                    new Quote { Text = "I've come to save you" }
                }
            };

            _context.Samurais.Add(samurai);
            //Console.WriteLine(_context.Entry(samurai).State);
            //DisplayStates(_context.ChangeTracker.Entries());
            _context.SaveChanges();
        }
        private static void InsertNewSamuraiWithManyQuotes()
        {
            var samurai = new Samurai
            {
                Name = "Kyūzō",
                Quotes = new List<Quote> {
                    new Quote {Text = "Watch out for my sharp sword!"},
                    new Quote {Text="I told you to watch out for the sharp sword! Oh well!" }
                }
            };
            _context.Samurais.Add(samurai);
            _context.SaveChanges();
        }
        private static void AddQuoteToExistingSamuraiWhileTracked()
        {
            var samurai = _context.Samurais.FirstOrDefault();
            samurai.Quotes.Add(new Quote
            {
                Text = "I bet you're happy that I've saved you!"
            });
            //DisplayStates(_context.ChangeTracker.Entries());
            _context.SaveChanges();
        }
        private static void AddQuoteToExistingSamuraiNotTracked(int samuraiId)
        {
            var samurai = _context.Samurais.Find(samuraiId);
            samurai.Quotes.Add(new Quote
            {
                Text = "Now that I saved you, will you feed me dinner?"
            });
            using (var newContext = new MyAppContext())
            {
                //newContext.Samurais.Update(samurai);
                newContext.Samurais.Attach(samurai);
                //DisplayStates(newContext.ChangeTracker.Entries());
                newContext.SaveChanges();
            }
        }
        private static void Simpler_AddQuoteToExistingSamuraiNotTracked(int samuraiId)
        {
            var quote = new Quote { Text = "Thanks for dinner!", SamuraiFK = samuraiId };
            using var newContext = new MyAppContext();
            newContext.Quotes.Add(quote);
            newContext.SaveChanges();
        }
        private static void DisplayStates(IEnumerable<EntityEntry> entries)
        {
            foreach (var entry in entries)
            {
                Console.WriteLine($"\nEntity: {entry.Entity.GetType().Name}, " +
                    $"\nState: {entry.State}");
            }
        }
        private static void EagerLoadSamuraiWithQuotes()
        {
            //var samuraiWithQuotes = _context.Samurais.Include(s=>s.Quotes).ToList();

            //var samuraiWithQuotes = _context.Samurais.AsSplitQuery().Include(s => s.Quotes).ToList();

            //var filteredInclude = _context.Samurais.Where(s => s.Name.Contains("Sampson"))
            //  .Include(s => s.Quotes).ToList();

            var filteredInclude = _context.Samurais
                .Include(s => s.Quotes.Where(q => q.Text.Contains("Thanks"))).ToList();


            //foreach (var s in samuraiWithQuotes)
            //{
            //    Console.WriteLine(s.Name);
            //    Console.WriteLine(s.Quotes.Count());
            //}
        }

        private static void ProjectSomeProperties()
        {
            //var someProperties = _context.Samurais.Select(s => new { s.Id, s.Name }).ToList();
            var someProperties = _context.Samurais.Select(s => new IdAndName(s.Id, s.Name)).ToList();
        }
        public struct IdAndName
        {
            public IdAndName(int id, string name)
            {
                Id = id;
                Name = name;
            }
            public int Id;
            public string Name;
        }
        private static void ProjectSamuraisWithQuotes()
        {
            //var somePropsWithQuotes = _context.Samurais
            //    .Select(s => new { s.Id, s.Name, NumberOfQuotes = s.Quotes.Count })
            //    .ToList();

            //var somePropsWithQuotes = _context.Samurais
            //.Select(s => new
            //{
            //    s.Id,
            //    s.Name,
            //    HappyQuotes = s.Quotes.Where(q => q.Text.Contains("happy"))
            //}).ToList();

            var samuraisAndQuotes = _context.Samurais
            .Select(s => new
            {
                Samurai = s,
                HappyQuotes = s.Quotes.Where(q => q.Text.Contains("happy"))
            })
            .ToList();
        }

        private static void ExplicitLoadQuotes()
        {
            //_context.Set<Horse>().Add(new Horse { SamuraiId = 3, Name = "Mr. Ed" });
            //_context.SaveChanges();
            //_context.ChangeTracker.Clear();

            var samurai = _context.Samurais.Find(3);
            _context.Entry(samurai).Collection(s => s.Quotes).Load();
            _context.Entry(samurai).Reference(s => s.Horse).Load();
        }
        private static void LazyLoadQuotes()
        {
            // Every Navigation Property in every Entity must be virtual
            // Add Microsoft.EntityFramework.Proxies package
            // OnConfiguration optionsBulder.UseLazyLoadingProxies()
            // OR
            // Add Microsoft.EntityFrameworkCore.Abstractions
            // Use ILazyLoader to do without Proxies
            var samurai = _context.Samurais.Find(3);
            var quoteCount = samurai.Quotes.Count();  //won't work without LL setup
        }

        private static void ModifyingRelatedDataWhenTracked()
        {
            var samurai = _context.Samurais.Include(s => s.Quotes)
                                  .FirstOrDefault(s => s.Id == 4);
            samurai.Quotes[0].Text = "Did you hear that?";
            _context.Quotes.Remove(samurai.Quotes[2]);
            _context.SaveChanges();
        }
        private static void ModifyingRelatedDataWhenNotTracked()
        {
            var samurai = _context.Samurais.Include(s => s.Quotes)
                                  .FirstOrDefault(s => s.Id == 4);
            var quote = samurai.Quotes[0];
            quote.Text += "Did you hear that again?";

            using var newContext = new MyAppContext();
            //newContext.Quotes.Update(quote);
            newContext.Entry(quote).State = EntityState.Modified;
            newContext.SaveChanges();
        }

        private static void AddingNewSamuraiToAnExistingBattle()
        {
            var battle = _context.Battles.FirstOrDefault();
            battle.Samurais.Add(new Samurai { Name = "Takeda" });
            _context.SaveChanges();
        }
        private static void ReturnBattleWithSamurais()
        {
            var battle = _context.Battles.Include(b => b.Samurais).FirstOrDefault();
        }
        private static void ReturnAllBattlesWithSamurais()
        {
            var battles = _context.Battles.Include(b => b.Samurais).ToList();
        }

        private static void AddAllSamuraisToAllBattles()
        {
            //var allbattles = _context.Battles.ToList();
            //var allSamurais = _context.Samurais.ToList();
            // Solution 1
            //var allSamurais = _context.Samurais.Where(s => s.Id != 25).ToList();

            // Proper Solution
            var allbattles = _context.Battles.Include(b => b.Samurais).ToList();
            var allSamurais = _context.Samurais.ToList();

            foreach (var battle in allbattles)
            {
                battle.Samurais.AddRange(allSamurais);
            }
            _context.SaveChanges();
        }

        private static void RemoveSamuraiFromABattle()
        {
            var battleWithSamurai = _context.Battles
                .Include(b => b.Samurais.Where(s => s.Id == 25))
                .Single(s => s.BattleId == 1);
            var samurai = battleWithSamurai.Samurais[0];
            battleWithSamurai.Samurais.Remove(samurai);
            _context.SaveChanges();
        }

        private static void WillNotRemoveSamuraiFromABattle()
        {
            var battle = _context.Battles.Find(1);
            var samurai = _context.Samurais.Find(12);
            battle.Samurais.Remove(samurai);            //the relationship is not being tracked
            _context.SaveChanges();
        }

        private static void AddNewSamuraiWithHorse()
        {
            var samurai = new Samurai { Name = "Jina Ujichika" };
            samurai.Horse = new Horse { Name = "Silver" };
            _context.Samurais.Add(samurai);
            _context.SaveChanges();
        }

        private static void AddNewHorseToSamuraiUsingId()
        {
            var horse = new Horse { Name = "Scout", SamuraiId = 8 };
            _context.Add(horse);
            _context.SaveChanges();
        }

        private static void AddNewHorseToSamuraiObject()
        {
            var samurai = _context.Samurais.Find(25);
            samurai.Horse = new Horse { Name = "Black Beauty" };
            _context.SaveChanges();
        }

        private static void AddNewHorseToDisconnectedSamuraiObject()
        {
            var samurai = _context.Samurais.AsNoTracking().FirstOrDefault(s => s.Id == 5);
            samurai.Horse = new Horse { Name = "Mr. Ed" };

            using var newContext = new MyAppContext();
            newContext.Samurais.Attach(samurai);        // Unchanged if Id is avaiable // Added if Id is Not Avaiable

            // Entity State to be set as Modifeied or Deleted , we should have the Primary Key(Id) Value
            //newContext.Entry(samurai.Horse).State = EntityState.Modified;
            //newContext.Entry(samurai.Horse).State = EntityState.Deleted;
            DisplayStates(newContext.ChangeTracker.Entries());
            //newContext.SaveChanges();
        }

        private static void ReplaceAHorse()
        {
            var samurai = _context.Samurais.Include(s => s.Horse)
                                  .FirstOrDefault(s => s.Id == 3);
            samurai.Horse = new Horse { Name = "Trigger" };
            _context.SaveChanges();
        }
    }
}

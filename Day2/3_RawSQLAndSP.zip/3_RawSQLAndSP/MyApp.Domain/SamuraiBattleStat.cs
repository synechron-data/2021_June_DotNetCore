﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyApp.Domain
{
    public class SamuraiBattleStat
    {
        public string Name { get; set; }
        public int? NumberOfBattles { get; set; }
        public string EarliestBattle { get; set; }
    }
}

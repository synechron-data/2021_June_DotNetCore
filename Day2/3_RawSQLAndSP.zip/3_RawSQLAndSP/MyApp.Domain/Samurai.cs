﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;

namespace MyApp.Domain
{
    public class Samurai
    {
        //public Samurai()
        //{

        //}
        //private Samurai(ILazyLoader lazyLoader) {
        //    LazyLoader = lazyLoader;
        //}

        //private ILazyLoader LazyLoader { get; set; }

        public int Id { get; set; }

        public string Name { get; set; }

        // Navigation Property
        public List<Quote> Quotes { get; set; } = new List<Quote>();

        //private List<Quote> _quotes;
        //public List<Quote> Quotes {
        //    get => LazyLoader.Load(this, ref _quotes);
        //    set => _quotes = value;
        //}

        public List<Battle> Battles { get; set; } = new List<Battle>();

        public Horse Horse { get; set; }
    }
}
